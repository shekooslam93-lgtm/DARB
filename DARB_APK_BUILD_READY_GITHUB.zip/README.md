# DARB — Android APK Build Ready

هذه النسخة مرتبة لتُرفع إلى GitHub، وبعد الرفع سيقوم GitHub Actions ببناء APK تلقائيًا.

## من الهاتف
1. أنشئ Repository جديدًا على GitHub باسم `DARB`.
2. ارفع **محتويات هذا المجلد** (خصوصًا مجلد `DARB_Android` و`.github`).
3. افتح تبويب **Actions**.
4. اختر **Build DARB APK**.
5. شغّل **Run workflow** أو انتظر التشغيل بعد الرفع.
6. بعد انتهاء البناء افتح نتيجة التشغيل ثم قسم **Artifacts**.
7. نزّل `DARB-debug-apk.zip` وفك الضغط لتحصل على `app-debug.apk`.

ملاحظة: هذا يبني نسخة Debug للتجربة والتثبيت على الهاتف. النشر على Google Play يحتاج لاحقًا توقيع Release وإعداد مفتاح توقيع.
