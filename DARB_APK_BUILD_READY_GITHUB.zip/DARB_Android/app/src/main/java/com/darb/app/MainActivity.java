package com.darb.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 2001;
    private static final int GALLERY_REQUEST = 2002;
    private WebView web;
    private TextRecognizer recognizer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
        }
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    public class AndroidBridge {
        @JavascriptInterface public void openNativeCamera() {
            if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                return;
            }
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            try { startActivityForResult(i, CAMERA_REQUEST); } catch (Exception e) { sendError("تعذر فتح الكاميرا"); }
        }

        @JavascriptInterface public void openNativeGallery() {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            i.setType("image/*");
            try { startActivityForResult(i, GALLERY_REQUEST); } catch (Exception e) { sendError("تعذر فتح الاستديو"); }
        }

        @JavascriptInterface public void openMaps(String query) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))));
            } catch (Exception ignored) {}
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            if (requestCode == CAMERA_REQUEST && data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                runOcr(InputImage.fromBitmap((Bitmap)data.getExtras().get("data"), 0));
            } else if (requestCode == GALLERY_REQUEST && data.getData() != null) {
                runOcr(InputImage.fromFilePath(this, data.getData()));
            }
        } catch (Exception e) { sendError("تعذر تجهيز صورة البوليصة"); }
    }

    private void runOcr(InputImage image) {
        sendStatus("جاري قراءة البوليصة...");
        recognizer.process(image)
            .addOnSuccessListener(result -> {
                String text = result.getText() == null ? "" : result.getText();
                Parsed p = parse(text);
                String safeText = js(text);
                String safeName = js(p.name);
                String safePhone = js(p.phone);
                String safeOrder = js(p.order);
                String safeAddress = js(p.address);
                String script = "window.onDarbOcrResult(" + safeText + "," + safeName + "," + safePhone + "," + safeAddress + "," + safeOrder + ");";
                runJs(script);
            })
            .addOnFailureListener(e -> sendError("لم نتمكن من قراءة البوليصة. جرّب صورة أوضح ومباشرة."));
    }

    private static class Parsed { String name=""; String phone=""; String address=""; String order=""; }

    private Parsed parse(String text) {
        Parsed p = new Parsed();
        String normalized = text.replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4').replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9');
        Matcher phone = Pattern.compile("(?:\\+?966\\s?|0)?5\\d{8}").matcher(normalized.replaceAll("[ -]", ""));
        if (phone.find()) p.phone = phone.group();
        Matcher order = Pattern.compile("(?i)(?:order|shipment|رقم|no\\.?|#)\\s*[:#-]?\\s*(\\d{1,6})").matcher(normalized);
        if (order.find()) p.order = order.group(1);
        else {
            Matcher any = Pattern.compile("\\b\\d{1,6}\\b").matcher(normalized);
            if (any.find()) p.order = any.group();
        }
        String[] lines = text.split("\\n");
        for (String line : lines) {
            String l = line.trim();
            if (l.length() >= 3 && !l.matches(".*\\d{5,}.*") && p.name.isEmpty()) p.name = l;
        }
        p.address = text.trim();
        return p;
    }

    private String js(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "") + "\"";
    }

    private void runJs(String script) { runOnUiThread(() -> web.evaluateJavascript(script, null)); }
    private void sendStatus(String msg) { runJs("window.onDarbOcrStatus(" + js(msg) + ");"); }
    private void sendError(String msg) { runJs("window.onDarbOcrError(" + js(msg) + ");"); }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
